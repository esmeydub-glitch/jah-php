<?php

declare(strict_types=1);

require_once __DIR__ . '/../../src/bootstrap.php';

use Jah\Security\JahSalkToken;

$config = [
    'id' => 'jah_skycore64',
    'title' => 'JAH SkyCore 64',
    'width' => 1180,
    'height' => 664,
    'fps' => 60,
    'player' => ['id' => 'salk64', 'x' => 110, 'y' => 290, 'energy' => 160, 'speed' => 6, 'weapon' => 'quantum_lance'],
    'levels' => [
        ['id' => 'Quantum Boot', 'background' => 'quantum_blue', 'enemies' => 18, 'shots' => 70, 'particles' => 160, 'boss' => 'Gatekeeper Prime'],
        ['id' => 'Neural Highway', 'background' => 'neural_stream', 'enemies' => 34, 'shots' => 110, 'particles' => 260, 'boss' => 'Router Wraith'],
        ['id' => 'Cache Nebula', 'background' => 'cache_nebula', 'enemies' => 58, 'shots' => 160, 'particles' => 420, 'boss' => 'Cache Hydra'],
        ['id' => 'GPU Cathedral', 'background' => 'gpu_cathedral', 'enemies' => 96, 'shots' => 240, 'particles' => 700, 'boss' => 'Shader Seraph'],
        ['id' => 'SALK Singularity', 'background' => 'salk_singularity', 'enemies' => 150, 'shots' => 360, 'particles' => 1100, 'boss' => 'NEXUS-NULL 64'],
    ],
];

$json = (string) json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
$token = class_exists(JahSalkToken::class) ? JahSalkToken::make([
    'purpose' => 'game64_manifest',
    'game' => 'jah_skycore64',
    'payload_hash' => JahSalkToken::payloadHash($config),
    'payload' => $config,
]) : '';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>JAH SkyCore 64</title>
    <style>
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: radial-gradient(circle at 50% 20%, #172554, #020617 55%); color: #f8fafc; font-family: system-ui, sans-serif; }
        .jas-game64 { position: relative; overflow: hidden; border: 1px solid rgba(125,211,252,.45); background: #020617; perspective: 900px; box-shadow: 0 30px 140px rgba(59,130,246,.28); }
        .game64-config { display: none; }
        .game64-bg, .game64-world, .game64-hud, .game64-message { position: absolute; inset: 0; }
        .game64-world { transform-style: preserve-3d; overflow: hidden; }
        .layer-back { background: radial-gradient(circle at 70% 25%, rgba(56,189,248,.28), transparent 32%), radial-gradient(circle at 20% 80%, rgba(34,197,94,.16), transparent 28%), #020617; }
        .layer-mid { background-image: linear-gradient(rgba(125,211,252,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(125,211,252,.08) 1px, transparent 1px); background-size: 44px 44px; animation: grid64 7s linear infinite; transform: rotateX(56deg) translateY(190px); }
        .layer-front { box-shadow: inset 0 0 120px rgba(2,6,23,.88); pointer-events: none; }
        [data-bg64="salk_singularity"] .layer-back { background: radial-gradient(circle at 70% 25%, rgba(239,68,68,.34), transparent 34%), #12050a; }
        [data-bg64="gpu_cathedral"] .layer-back { background: radial-gradient(circle at 70% 25%, rgba(168,85,247,.32), transparent 34%), #09051a; }
        [data-bg64="cache_nebula"] .layer-back { background: radial-gradient(circle at 35% 65%, rgba(34,197,94,.26), transparent 36%), #04130d; }
        [data-bg64="neural_stream"] .layer-back { background: radial-gradient(circle at 60% 30%, rgba(14,165,233,.30), transparent 34%), #06111f; }
        .game64-hud { height: 66px; display: flex; align-items: center; gap: 22px; padding: 0 22px; background: rgba(2,6,23,.76); z-index: 30; box-sizing: border-box; backdrop-filter: blur(8px); }
        .game-title { margin-right: auto; color: #7dd3fc; text-shadow: 0 0 18px #38bdf8; font-size: 20px; }
        .game64-message { top: auto; bottom: 14px; height: 30px; z-index: 32; text-align: center; color: #cbd5e1; }
        .game64-start { position: absolute; inset: 66px 0 0; display: grid; place-items: center; align-content: center; gap: 12px; z-index: 50; background: rgba(2,6,23,.64); }
        .game64-start button { border: 1px solid #7dd3fc; background: linear-gradient(135deg, #172033, #0f172a); color: #f8fafc; padding: 16px 22px; font-weight: 900; cursor: pointer; box-shadow: 0 0 30px rgba(56,189,248,.42); }
        .player64 { position: absolute; width: 86px; height: 52px; clip-path: polygon(0 50%, 25% 6%, 82% 0, 100% 50%, 82% 100%, 25% 94%); background: linear-gradient(135deg, #e0f2fe, #38bdf8 30%, #2563eb 52%, #22c55e 100%); box-shadow: 0 0 24px #38bdf8, inset -12px 0 0 rgba(255,255,255,.25); will-change: transform; }
        .player64.hit64 { filter: brightness(2.2) saturate(1.6); }
        .enemy64 { position: absolute; width: 58px; height: 44px; clip-path: polygon(0 15%, 82% 0, 100% 50%, 82% 100%, 0 85%, 28% 50%); background: linear-gradient(135deg, #fb7185, #991b1b 58%, #f97316); box-shadow: 0 0 18px rgba(248,113,113,.78); will-change: transform; }
        .boss64-node { position: absolute; display: grid; place-items: center; width: 190px; height: 110px; border: 1px solid #f87171; background: linear-gradient(135deg, rgba(69,10,10,.95), rgba(153,27,27,.92)); color: #fecaca; font-weight: 900; text-align: center; box-shadow: 0 0 42px rgba(239,68,68,.72); will-change: transform; }
        .shot64 { position: absolute; width: 30px; height: 5px; border-radius: 99px; background: #facc15; box-shadow: 0 0 14px #facc15; will-change: transform; }
        .shot64.charged { width: 70px; height: 9px; background: #7dd3fc; box-shadow: 0 0 24px #38bdf8; }
        .core64 { position: absolute; width: 30px; height: 30px; border-radius: 10px; background: conic-gradient(#22c55e, #7dd3fc, #facc15, #22c55e); box-shadow: 0 0 26px rgba(34,197,94,.8); will-change: transform; }
        .particle64 { position: absolute; width: 3px; height: 3px; background: #7dd3fc; box-shadow: 0 0 8px #7dd3fc; will-change: transform; }
        @keyframes grid64 { from { background-position: 0 0; } to { background-position: -176px 0; } }
    </style>
    <script src="/actionscript-php-jah/assets/jah-skycore64.js" defer></script>
</head>
<body>
    <main id="jah_skycore64" class="jas-game64" data-asjah-game="skycore64" data-salk-token="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>" style="width:1180px;height:664px;">
        <script type="application/json" class="game64-config"><?= str_replace('</script', '<\/script', $json) ?></script>
        <section class="game64-bg layer-back"></section>
        <section class="game64-bg layer-mid"></section>
        <section class="game64-bg layer-front"></section>
        <section class="game64-hud">
            <strong class="game-title">JAH SkyCore 64</strong>
            <span>LEVEL <b data-hud64="level">1</b></span>
            <span>SCORE <b data-hud64="score">0</b></span>
            <span>ENERGY <b data-hud64="energy">160</b></span>
            <span>CORES <b data-hud64="cores">0</b></span>
            <span>CHARGE <b data-hud64="charge">0</b>%</span>
        </section>
        <section class="game64-world">
            <div class="player64"></div>
            <div class="shots64"></div>
            <div class="orbs64"></div>
            <div class="particles64"></div>
            <div class="enemies64"></div>
            <div class="boss64"></div>
        </section>
        <section class="game64-start"><button type="button" data-game64-start>INICIAR SKYCORE 64</button><span>WASD/Flechas mover · Espacio dispara · Q laser cargado · E dash</span></section>
        <section class="game64-message">Sistema listo</section>
    </main>
</body>
</html>

<?php

declare(strict_types=1);

$html = shell_exec('php ' . escapeshellarg(__DIR__ . '/../examples/animacion/jah_skycore64.php'));

if (!is_string($html)) {
    fwrite(STDERR, "skycore64 did not render\n");
    exit(1);
}

foreach ([
    'JAH SkyCore 64',
    'data-asjah-game="skycore64"',
    'data-salk-token=',
    'data-game64-start',
    'NEXUS-NULL 64',
    'jah-skycore64.js',
] as $expected) {
    if (!str_contains($html, $expected)) {
        fwrite(STDERR, "missing {$expected}\n");
        exit(1);
    }
}

if (!preg_match('/<script type="application\/json" class="game64-config">(.*?)<\/script>/s', $html, $matches)) {
    fwrite(STDERR, "missing game64 json\n");
    exit(1);
}

$manifest = json_decode($matches[1], true);
if (!is_array($manifest) || count($manifest['levels'] ?? []) !== 5) {
    fwrite(STDERR, "invalid game64 manifest\n");
    exit(1);
}

echo "JAH SkyCore 64 smoke PASS\n";
